npm install ws
WebSocket 서버를 시작하려면 => node server.js