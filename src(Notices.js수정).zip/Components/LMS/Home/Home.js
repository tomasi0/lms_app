export function Home() {
    return (
        <>
            <h1>강의 정보를 제공하는 웹페이지입니다.</h1>
        </>
    );
}
