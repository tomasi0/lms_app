export function Logout() {
  return (
    <>
      <h1>Logout</h1>
    </>
  );
}
