export function MyPage() {
    return (
        <>
            <h1>마이페이지 입니다.</h1>
        </>
    );
}
